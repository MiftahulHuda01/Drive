package com.huda.drive.ui.admin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.huda.drive.R

class AdminMainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_main)
    }
}