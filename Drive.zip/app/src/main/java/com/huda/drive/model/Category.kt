package com.huda.drive.model

data class Category(
    val name: String,
    val img: Int
)
